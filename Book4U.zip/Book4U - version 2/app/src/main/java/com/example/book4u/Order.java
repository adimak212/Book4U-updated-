package com.example.book4u;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class Order implements Parcelable {
    private String adress;
    private String name;
    private String bookName;
    private String imageURL;
    private int price;
    private String phone;

    public Order(String adress, String name, String bookName, String imageURL, int price, String phone) {
        this.adress = adress;
        this.name = name;
        this.bookName = bookName;
        this.imageURL = imageURL;
        this.price = price;
        this.phone = phone;
    }
    public Order() {
        this.adress = "adress";
        this.name = "name";
        this.bookName = "bookName";
        this.imageURL = "imageURL";
        this.price = 10;
        this.phone = "phone";
    }

    protected Order(Parcel in) {
        adress = in.readString();
        name = in.readString();
        bookName = in.readString();
        imageURL = in.readString();
        price = in.readInt();
        phone = in.readString();
    }

    public static final Creator<Order> CREATOR = new Creator<Order>() {
        @Override
        public Order createFromParcel(Parcel in) {
            return new Order(in);
        }

        @Override
        public Order[] newArray(int size) {
            return new Order[size];
        }
    };

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(adress);
        dest.writeString(name);
        dest.writeString(bookName);
        dest.writeString(imageURL);
        dest.writeInt(price);
        dest.writeString(phone);
    }
}

