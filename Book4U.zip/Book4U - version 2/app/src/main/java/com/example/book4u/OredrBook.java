package com.example.book4u;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class OredrBook extends AppCompatActivity {
    Button order;
    EditText address;
    Book book;
    TextView bookName , price  ;
    ImageView bookCover;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference myref;

    Order newOrder;

    SharedPreferences RememebrMe ;


    AlertDialog.Builder adb;
    Book changeBok;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oredr_book);
        bookName = findViewById(R.id.BookName);
        bookCover = findViewById(R.id.BookCover);
        price = findViewById(R.id.bookPriceInOrder);
        address = findViewById(R.id.OrderAddress);
        order = findViewById(R.id.Order);
        book = getIntent().getParcelableExtra("ClickedBook");
        bookName.setText(book.getBook_title());
        Picasso.get().load(book.getImage_url()).into(bookCover);
     //   price.setText(book.getPrice());
        firebaseDatabase=FirebaseDatabase.getInstance();
        RememebrMe = getSharedPreferences("UserLogedIn" , 0);
        myref = firebaseDatabase.getReference("Orders");
        order.setClickable(true);
        adb = new AlertDialog.Builder(OredrBook.this);
        adb.setTitle("Your order has been received , thank you for purchase  :)");
        adb.setCancelable(false);
        adb.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent toHome = new Intent(OredrBook.this , ButtonNevigetionMainPage.class);
                toHome.putExtra("flag" , 3);
                startActivity(toHome);
                finish();
            }
        });

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String addressString = address.getText().toString();
                myref = firebaseDatabase.getReference("Users");
                myref = myref.child(RememebrMe.getString("Email" , "").toString().replace("." , "|"));
                myref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        newOrder = new Order(addressString, RememebrMe.getString("Email" , "").toString().replace("." , "|") , book.getBook_title() , book.getImage_url() ,book.getPrice() ,snapshot.child("phoneNumber").getValue().toString());

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
                myref = firebaseDatabase.getReference("Orders");
                myref.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        myref.child(RememebrMe.getString("Email" , "").toString().replace("." , "|")).child(newOrder.getBookName()).setValue(newOrder);
                        updateStock();
                        adb.show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });



            }
        });

    }


    public void updateStock (){
        myref = firebaseDatabase.getReference("Books").child(book.getBook_title());
        myref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                changeBok = snapshot.getValue(Book.class);
                changeBok.setStock(changeBok.getStock()-1);
                myref.child("stock").setValue(changeBok.getStock());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}