package com.example.book4u;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.List;

public class BookAdapter extends RecyclerView.Adapter<BookAdapter.ViewHolder> {

    private List<Book> books;

    public List<Book> getBooks() {
        return books;
    }

    public BookAdapter(List<Book> books ) {
        this.books = books;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.book_recycler,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.title.setText(books.get(position).getBook_title());
        holder.author.setText(books.get(position).getBook_authors());
        holder.rating.setText(books.get(position).getBook_rating());
        holder.geners.setText(books.get(position).getGenres());
        String imageURL = books.get(position).getImage_url();

        if(!imageURL.isEmpty()) {
            Picasso.get().load(imageURL).into(holder.cover);
        }
    }

    @Override
    public int getItemCount() {
        return books.size();
    }
    public List<Book> getList(){
        return books;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView title;
        TextView author;
        TextView geners;
        TextView rating;
        ImageView cover;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.BookName);
            author = itemView.findViewById(R.id.BookAuthor);
            geners = itemView.findViewById(R.id.BookGeners);
            rating = itemView.findViewById(R.id.BookRating);
            cover = itemView.findViewById(R.id.BookCover);


        }
    }
}
