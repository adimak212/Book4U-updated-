package com.example.book4u;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.android.material.card.MaterialCardView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {
    public static final DecimalFormat df = new DecimalFormat("0.00");
    BookAdapter adapter;
    ArrayList<Book> books = new ArrayList<>();
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;


    FirebaseDatabase firebaseDatabase;
    DatabaseReference myref;

    SharedPreferences RememebrMe;
    SharedPreferences.Editor editor;
    Intent back;

    String code ;
    User u ;
    float value = 0;



    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.homeRecyclerView);
        firebaseDatabase = FirebaseDatabase.getInstance();
        back = new Intent(getContext() , ButtonNevigetionMainPage.class);
        RememebrMe = getContext().getSharedPreferences("UserLogedIn" , 0);
        myref = firebaseDatabase.getReference("UsersFavorites");
        myref = myref.child(RememebrMe.getString("Email", "").replace(".", "|"));
        adapter = new BookAdapter(books);
        layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
        myref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Book book = dataSnapshot.getValue(Book.class);
                    books.add(book);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        myref = firebaseDatabase.getReference("Users");
        myref = myref.child(RememebrMe.getString("Email", "").replace(".", "|"));
        myref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                u = snapshot.getValue(User.class);
                code = u.getCode();
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl("https://api.currencybeacon.com" + "/")
                        .addConverterFactory(GsonConverterFactory.create())
                        .build();
                retrofit.create(CurrencyApi.class).getValue("4SBqCstTeBg1jdgdla02OVO58bcLUMqh" , "USD" , code , 1).enqueue(new Callback<Coin>() {
                    @Override
                    public void onResponse(Call<Coin> call, Response<Coin> response) {
                        if (response.body() !=null && response.isSuccessful()){
                            value = response.body().getValue();
                            value = Float.parseFloat(df.format(value));
                            editor = RememebrMe.edit();
                            editor.putFloat("CoinValue" , value);
                            editor.commit();
                        }
                    }

                    @Override
                    public void onFailure(Call<Coin> call, Throwable t) {

                    }
                });


            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });




        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getContext(), recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent toBook = new Intent(getContext(), InBook.class);
                toBook.putExtra("ClickedBook",adapter.getBooks().get(position));
                toBook.putExtra("isFromHome" , true);
                startActivity(toBook);
            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        }));




    }
}