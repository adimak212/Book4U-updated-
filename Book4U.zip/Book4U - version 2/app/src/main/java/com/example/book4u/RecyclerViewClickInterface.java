package com.example.book4u;

public interface RecyclerViewClickInterface {
        void onItemClick (int position);
        void onLongItemClick(int position);
}
