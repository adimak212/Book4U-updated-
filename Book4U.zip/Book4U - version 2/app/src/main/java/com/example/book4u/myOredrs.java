package com.example.book4u;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SearchView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.card.MaterialCardView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class myOredrs extends AppCompatActivity {

    OrderAdapter adapter;
    ArrayList<Order> orders = new ArrayList<>();
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    SearchView searchBar;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference myref;

    SharedPreferences RememebrMe;

    ImageButton BackToProfile;

    Intent back;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_oredrs);
        recyclerView = findViewById(R.id.myOrdersRecyclerView);
        BackToProfile = findViewById(R.id.BackToProfile2);
        firebaseDatabase = FirebaseDatabase.getInstance();
        back = new Intent(myOredrs.this , ButtonNevigetionMainPage.class);
        RememebrMe = getSharedPreferences("UserLogedIn" , 0);
        myref = firebaseDatabase.getReference("Orders");
        myref = myref.child(RememebrMe.getString("Email", "").replace(".", "|"));
        adapter = new OrderAdapter(orders);
        layoutManager = new LinearLayoutManager(myOredrs.this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        myref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Order order = dataSnapshot.getValue(Order.class);
                    orders.add(order);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        BackToProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back.putExtra("flag" , 1);
                startActivity(back);
            }
        });

        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(myOredrs.this, recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent toBook = new Intent(myOredrs.this, InBook.class);
                toBook.putExtra("ClickedBook",adapter.getOrders().get(position));
                toBook.putExtra("isFromOrders" , true);
                startActivity(toBook);
            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        }));

    }
}