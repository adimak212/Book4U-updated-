package com.example.book4u;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class ButtonNevigetionMainPage extends AppCompatActivity {
    Intent intent;
    FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();

    SharedPreferences sharedPreferences;
    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button_nevigetion_main_page);
        intent = getIntent();
        if (intent.getIntExtra("flag" , 0) == 1){
            replaceFragment(new ProfileFragment());
        }
        else if (intent.getIntExtra("flag" , 0) == 2) {
            replaceFragment(new SearchFragment());
        }
        else {
            replaceFragment(new HomeFragment());
        }
        sharedPreferences = getSharedPreferences("UserLogedIn" , 0);

        Bundle bundle = new Bundle();
        if (sharedPreferences.getBoolean("isChecked" , false)){
            bundle.putString("CurrentUserEmail" , sharedPreferences.getString("Email" , ""));
        }
        else {
            bundle.putString("CurrentUserEmail" , intent.getStringExtra("CurrentUserEmail"));
        }
        ProfileFragment profileFragment = new ProfileFragment();
        profileFragment.setArguments(bundle);
        bottomNavigationView =  findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            if (item.getItemId() == R.id.home){
                replaceFragment(new HomeFragment());
            }// home pressed
            if(item.getItemId() == R.id.profile){
                replaceFragment(profileFragment);
            }// profile pressed
            if(item.getItemId() == R.id.Search){
                replaceFragment(new SearchFragment());
            }// profile pressed
            return true;
        });

    }


    private void replaceFragment(Fragment fragment) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frameLayoutBottom, fragment);
        fragmentTransaction.commit();
    }
}