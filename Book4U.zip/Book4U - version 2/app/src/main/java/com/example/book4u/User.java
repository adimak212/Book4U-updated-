package com.example.book4u;

public class User {
    private String FullName;
    private String AccountName;
    private String Email;
    private String Password;
    private String PhoneNumber;
    private String picName;
    private String code;



    public User(String fullName, String accountName, String email, String password, String phoneNumber , String picName,String code) {
        FullName = fullName;
        AccountName = accountName;
        Email = email;
        Password = password;
        PhoneNumber = phoneNumber;
        this.picName = picName;
        this.code = code;
    }

    public User() {
        this.AccountName = "";
        this.Email = "";
        this.Password = "";
        this.picName="";
        this.code = "USD";
    }

    public String getFullName() {
        return FullName;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setFullName(String fullName) {
        FullName = fullName;
    }

    public String getAccountName() {
        return AccountName;
    }

    public void setAccountName(String accountName) {
        AccountName = accountName;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getPicName() {
        return picName;
    }

    public void setPicName(String picName) {
        this.picName = picName;
    }

    @Override
    public String toString() {
        return "User{" +
                "AccountName='" + AccountName + '\'' +
                ", Email='" + Email + '\'' +
                ", Password='" + Password + '\'' +
                '}';
    }
}
