package com.example.book4u;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface CurrencyApi {
    @GET("v1/currencies")
    Call<AllCurrencies> getAllCoins(@Query("api_key") String token);

    @GET("v1/convert")
    Call<Coin> getValue (@Query("api_key") String token , @Query("from") String code ,@Query("to") String des , @Query("amount") int amount);
}
