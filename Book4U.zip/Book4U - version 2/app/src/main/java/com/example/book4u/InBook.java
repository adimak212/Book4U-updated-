package com.example.book4u;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class InBook extends AppCompatActivity {
    Book book;
    TextView bookName , bookDes  , bookRating , bookPrice;
    ImageView bookCover;
    ArrayList<Book> favBooks = new ArrayList<>();
    Button favCheck;
    SharedPreferences sharedPreferences;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference myref;
    Button Order  ;

    ImageButton Back;
    Intent backToSearch , backToOrders , backToHome;




    SharedPreferences.Editor shardP;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_in_book);
        bookName = findViewById(R.id.InBookTitle);
        bookDes = findViewById(R.id.InBookDes);
        bookCover = findViewById(R.id.InBookCover);
        favCheck = findViewById(R.id.favCheck);
        Order = findViewById(R.id.OrderBook);
        Back = findViewById(R.id.BackToProfile);
        book = getIntent().getParcelableExtra("ClickedBook");
        bookRating = findViewById(R.id.InBookRating);
        bookName.setText(book.getBook_title());
        bookDes.setText(book.getBook_desc());
        bookRating.setText(book.getBook_rating());
        Picasso.get().load(book.getImage_url()).into(bookCover);
        sharedPreferences = getSharedPreferences("UserLogedIn" , 0);
        Order.setText("Order Now!  " + " (" + (book.getPrice() * sharedPreferences.getFloat("CoinValue" , 1) ) + sharedPreferences.getString("coinSymbol" , "") +  ")");
        sharedPreferences = getSharedPreferences("UserLogedIn" , 0);
        firebaseDatabase = FirebaseDatabase.getInstance();
        myref = firebaseDatabase.getReference("UsersFavorites");
        myref = myref.child(sharedPreferences.getString("Email", "").replace(".", "|"));
        myref = myref.child(book.getBook_title());


        myref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.child("fav").getValue() != null) {
                    if (snapshot.child("fav").getValue().toString().equals("true")) {
                        favCheck.setText("remove from favorites");
                    }
                }
            }


            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        favCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (favCheck.getText().equals("add to favorites!")){
                    book.setFav(true);
                    updateFav(true);
                    favCheck.setText("remove from favorites");
                    myref = firebaseDatabase.getReference("UsersFavorites");
                    myref = myref.child(sharedPreferences.getString("Email" , "").replace("." , "|"));
                    myref = myref.child(book.getBook_title());
                    myref.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            myref.setValue(book);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });


                }
                else if (favCheck.getText().equals("remove from favorites")){
                    updateFav(false);
                    myref = firebaseDatabase.getReference("UsersFavorites");
                    myref = myref.child(sharedPreferences.getString("Email" , "").replace("." , "|"));
                    myref.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            favCheck.setText("add from favorites");
                            myref.child(book.getBook_title()).removeValue();

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }

                    });


                }
                favCheck.setClickable(true);
            }
        });
        Back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (getIntent().getBooleanExtra("isFromOrders" , false)){
                    backToOrders = new Intent(InBook.this, myOredrs.class);
                    startActivity(backToOrders);
                    finish();
                } else if (getIntent().getBooleanExtra("isFromHome" , false)) {
                    backToHome = new Intent(getApplicationContext(), ButtonNevigetionMainPage.class);
                    startActivity(backToHome);
                    finish();

                } else {
                    backToSearch = new Intent(InBook.this, ButtonNevigetionMainPage.class);
                    backToSearch.putExtra("flag", 2);
                    startActivity(backToSearch);
                    finish();
                }
            }
        });

        Order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toOrder = new Intent(InBook.this , OredrBook.class );
                toOrder.putExtra("ClickedBook",book);
                startActivity(toOrder);
                finish();
            }
        });
    }

    public void updateFav(boolean what) {
        myref = firebaseDatabase.getReference("UsersFavorites");
        myref = myref.child(sharedPreferences.getString("Email", "").replace(".", "|"));
        myref = myref.child(book.getBook_title());
        myref.child("fav").setValue(what);
    }


}