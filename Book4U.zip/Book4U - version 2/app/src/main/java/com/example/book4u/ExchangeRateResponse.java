package com.example.book4u;

import com.google.gson.annotations.SerializedName;
import java.util.Map;

public class ExchangeRateResponse {
    @SerializedName("base")
    private String base;

    @SerializedName("rates")
    private Map<String, Double> rates;

    // Getters
    public String getBase() {
        return base;
    }

    public Map<String, Double> getRates() {
        return rates;
    }
}
