package com.example.book4u;

import android.os.Parcel;
import android.os.Parcelable;

public class Coin implements Parcelable {
    private String name;
    private String short_code;
    private String symbol;
    private float value;

    public Coin(String name, String short_code, String symbol) {
        this.name = name;
        this.short_code = short_code;
        this.symbol = symbol;
        this.value = 1;
    }
    public Coin(String name, String short_code, String symbol , float value) {
        this.name = name;
        this.short_code = short_code;
        this.symbol = symbol;
        this.value = value;
    }

    public Coin() {
        this.name = "";
        this.short_code = "";
        this.symbol = "";
        this.value =1;
    }

    protected Coin(Parcel in) {
        name = in.readString();
        short_code = in.readString();
        symbol = in.readString();
        value = in.readFloat();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(short_code);
        dest.writeString(symbol);
        dest.writeFloat(value);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Coin> CREATOR = new Creator<Coin>() {
        @Override
        public Coin createFromParcel(Parcel in) {
            return new Coin(in);
        }

        @Override
        public Coin[] newArray(int size) {
            return new Coin[size];
        }
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getShort_code() {
        return short_code;
    }

    public void setShort_code(String short_code) {
        this.short_code = short_code;
    }

    public String getSymbol() {
        return symbol;
    }

    public void setSymbol(String symbol) {
        this.symbol = symbol;
    }

    public float getValue() {
        return value;
    }

    public void setValue(float value) {
        this.value = value;
    }

}
