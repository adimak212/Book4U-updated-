package com.example.book4u;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class BaseAdapter extends ArrayAdapter<String> {
    public BaseAdapter(Context c, int r, ArrayList<String> pass) {
        super(c, r, pass);

    }

    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_view_profile_page, parent, false);
        }// if

        String p = getItem(position);
        TextView textView = (TextView) convertView.findViewById(R.id.TextProfilePage);

        textView.setText(p);
        return convertView;
    }
}
