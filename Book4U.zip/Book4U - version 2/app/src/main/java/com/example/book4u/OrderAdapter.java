package com.example.book4u;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

public class OrderAdapter extends RecyclerView.Adapter<OrderAdapter.ViewHolder> {

    private List<Order> orders;

    public OrderAdapter() {

    }

    public List<Order> getOrders() {
        return orders;
    }

    public OrderAdapter(List<Order> orders ) {
        this.orders = orders;
    }

    @NonNull
    @Override
    public OrderAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.order_recycelr,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.title.setText(orders.get(position).getBookName());
        holder.address.setText(orders.get(position).getAdress());
        String imageURL = orders.get(position).getImageURL();
        Picasso.get().load(imageURL).into(holder.cover);
    }


    @Override
    public int getItemCount() {
        return orders.size();
    }
    public List<Order> getList(){
        return orders;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView address;
        TextView price;
        ImageView cover;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.BookNameOrder);
            address= itemView.findViewById(R.id.BookAddressOrder);
            cover = itemView.findViewById(R.id.BookCoverOrder);


        }
    }
}
