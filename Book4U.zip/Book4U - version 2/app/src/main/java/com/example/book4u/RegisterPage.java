package com.example.book4u;

import android.Manifest;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;

public class RegisterPage extends AppCompatActivity {

    ImageView profileImage;
    Uri uri;
    AlertDialog.Builder adb;
    AlertDialog ad;
    private static final int MY_CAMERA_REQUEST_CODE = 100;
    private static final int FROM_GALLERY = 1;
    private static final int FROM_CAMERA = 2;

    ActivityResultLauncher activityResultLauncher;
    int flag;
    byte[] bytes;
    String picName="";
    StorageReference mStorageRef;
    FirebaseAuth firebaseAuth;
    ProgressDialog p;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference myref;
    boolean f=false;
    Intent backToLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_page);
        profileImage = findViewById(R.id.ProfileImage);
        firebaseAuth = FirebaseAuth.getInstance();
        backToLogin = new Intent(this , LoginScreen.class);
        activityResultLauncher= registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {


                        if (result.getData()!=null && result.getData().getAction()==null &&result.getResultCode() == Activity.RESULT_OK) {
                            Intent data = result.getData();
                            uri = data.getData();
                            picName=System.currentTimeMillis() + "."+ getFileExtension(uri);
                            Toast.makeText(RegisterPage.this, picName, Toast.LENGTH_LONG).show();
                            flag=FROM_GALLERY;
                            profileImage.setImageURI(uri);
                            f= true;//boolean if must enter picture


                        }


                        else if (result.getData()!=null   && result.getResultCode() == Activity.RESULT_OK) {
                            Bitmap bitmap = (Bitmap) result.getData().getExtras().get("data");
                            picName=System.currentTimeMillis() + "."+ "jpg";
                            Toast.makeText(RegisterPage.this, picName, Toast.LENGTH_LONG).show();
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                            bytes = baos.toByteArray();
                            profileImage.setImageBitmap(bitmap);
                            flag=FROM_CAMERA;
                            f= true;


                        }

                    }
                });

        //Firebase בישראל פותח שרת באירופה ואנדרואיד מתחבר אוטומטית לארצות הברית
        // לשים לב לזה בפעמים הבאות. חוסך הרבה כאב ראש ובדיקה באינטרנט
        firebaseDatabase = FirebaseDatabase.getInstance();
        myref=firebaseDatabase.getReference("Users");
        RegisterPage th = this;
        EditText email = findViewById(R.id.EmailRegister),pass=findViewById(R.id.PassWordRegister),userName = findViewById(R.id.AccountNameRegister) , fullname = findViewById(R.id.FullNameRegister) , phone = findViewById(R.id.PhoneRegister) ;
        findViewById(R.id.AddMeButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                p= new ProgressDialog(th);
                p.setMessage("Register In Progress");
                p.show();
                if(isValid(email,pass))
                    firebaseAuth.createUserWithEmailAndPassword(email.getText().toString(), pass.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            //if (task.isSuccessful()) {
                                User u = new User(fullname.getText().toString(),userName.getText().toString(), email.getText().toString() , pass.getText().toString(),phone.getText().toString() , picName,"USD");
                                myref=myref.child(email.getText().toString().replace(".", "|"));
                                //myref.push().setValue(u);
                                myref.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                                        myref.setValue(u);

                                        Log.d("FB","DataAdded");
                                    }

                                    @Override
                                    public void onCancelled(@NonNull DatabaseError error) {
                                        Log.e("FB","ERROR");
                                    }
                                });
                                if (flag == FROM_GALLERY) {
                                    mStorageRef = FirebaseStorage.getInstance().getReference("Images/users/" + email.getText().toString().replace('.', '|'));
                                    mStorageRef = mStorageRef.child(picName);
                                    mStorageRef.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {

                                        @Override
                                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                            Toast.makeText(RegisterPage.this, "תמונה הועלתה", Toast.LENGTH_LONG).show();
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {

                                            Toast.makeText(RegisterPage.this, "" + e.getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    });
                                }
                                else{

                                    mStorageRef = FirebaseStorage.getInstance().getReference("Images/users/" + email.getText().toString().replace('.', '|'));
                                    mStorageRef = mStorageRef.child(picName);
                                    UploadTask uploadTask = mStorageRef.putBytes(bytes);
                                    Toast.makeText(RegisterPage.this, "תמונה הועלתה", Toast.LENGTH_LONG).show();


                                }
                                p.dismiss();
                                Toast.makeText(th, "ההרשמה הצליחה!", Toast.LENGTH_LONG).show();
                                startActivity(backToLogin);
                            }

                      //  }
                    }).addOnFailureListener(new OnFailureListener()
                    {
                        @Override public void onFailure(@NonNull Exception e) {
                            Toast.makeText(RegisterPage.this,
                                    e.getMessage(), Toast.LENGTH_LONG).show();
                            p.dismiss();
                        }
                    });
            }
        });
        findViewById(R.id.ProfileImage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                adb = new AlertDialog.Builder(th);
                adb.setTitle("pick picture");
                adb.setMessage("choose picture from gallery/camera");

                adb.setCancelable(true);
                adb.setPositiveButton("גלריה", new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface d, int i) {
                        Intent intent = new Intent();
                        intent.setType("image/*");
                        intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
                        activityResultLauncher.launch(intent);
                    }
                });
                adb.setNeutralButton("מצלמה", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int i) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED) {
                            if (ActivityCompat.checkSelfPermission(RegisterPage.this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                                requestPermissions(new String[]{android.Manifest.permission.CAMERA}, MY_CAMERA_REQUEST_CODE);
                            }
                        }
                        else {
                            Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                            activityResultLauncher.launch(intent);
                        }
                    }
                });
                ad = adb.create();
                ad.show();
            }
        });
    }
    public boolean isValid(EditText email,EditText pass){
        if (!
                Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()
        ){
            email.setError("Invalid email");
            email.setFocusable(true);
            return false;
        }
        else if (pass.getText().toString().length()<6){
            pass.setError("password length at least 6 characters");
            pass.setFocusable(true);
            return false;
        }
        return true;
    }
    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_REQUEST_CODE) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(RegisterPage.this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                activityResultLauncher.launch(cameraIntent);
            } else {
                Toast.makeText(RegisterPage.this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }
}