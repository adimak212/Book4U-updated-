package com.example.book4u;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.card.MaterialCardView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SearchFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SearchFragment extends Fragment {

    BookAdapter adapter;
    ArrayList<Book> books = new ArrayList<>();
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    SearchView searchBar;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference myref;

    ArrayAdapter<String> arrayAdapter;

    MaterialCardView materialCardView;

    boolean[] selectedCat;
    ArrayList<Integer> IntList = new ArrayList<>();
    TextView catTextView;
    String[] list = {"Fantasy", "Classics" ,"Romance" ,"Fiction" ,"Non-Fiction" ,"Young Adult" };

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public SearchFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SearchFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SearchFragment newInstance(String param1, String param2) {
        SearchFragment fragment = new SearchFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        recyclerView = view.findViewById(R.id.BookRecycle);
        searchBar = view.findViewById(R.id.searchView);
        materialCardView = view.findViewById(R.id.selectCat);
        catTextView = view.findViewById(R.id.CatHint);
        selectedCat = new boolean[list.length];
        arrayAdapter = new ArrayAdapter<String>(getContext(), R.layout.cat_list, list);
        adapter = new BookAdapter(books);
        layoutManager = new LinearLayoutManager(view.getContext());
        firebaseDatabase = firebaseDatabase.getInstance();
        myref = firebaseDatabase.getReference("Books");
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);
        myref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()) {
                    Book book = dataSnapshot.getValue(Book.class);
                    books.add(book);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        recyclerView.addOnItemTouchListener(new RecyclerItemClickListener(getContext(), recyclerView, new RecyclerItemClickListener.OnItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                Intent toBook = new Intent(getContext(), InBook.class);
                toBook.putExtra("ClickedBook",adapter.getBooks().get(position));
                startActivity(toBook);
            }

            @Override
            public void onLongItemClick(View view, int position) {

            }
        }));
        searchBar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                adapter = new BookAdapter(search());
                recyclerView.setAdapter(adapter);
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                adapter = new BookAdapter(search());
                recyclerView.setAdapter(adapter);
                return false;
            }
        });

        materialCardView.setOnClickListener(v -> {
            showCatDialog();
        });

    }

    private void showCatDialog() {
        AlertDialog.Builder ad = new AlertDialog.Builder(getContext());
        ad.setTitle("select Categories");
        ad.setCancelable(false);
        ad.setMultiChoiceItems(list, selectedCat, new DialogInterface.OnMultiChoiceClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                if (isChecked){
                    IntList.add(which);

                }
                else {
                    for (int i = 0 ; i <IntList.size() ; i++){
                        if (IntList.get(i) == which){IntList.remove(i);}
                    }
                }
            }
        }).setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ArrayList<String> cat = new ArrayList<>();
                String categories = "";
                for (int i = 0 ; i <IntList.size(); i++){
                    cat.add(list[IntList.get(i)]);
                    if (i != IntList.size()){

                    }
                }
                for (int i = 0 ; i< cat.size(); i ++){
                    categories += cat.get(i);
                    categories += " , ";
                }
                catTextView.setHint(categories);
                if (categories.equals("")){ catTextView.setHint("select cat.");}
                adapter = new BookAdapter(searchByCat(cat));
                recyclerView.setAdapter(adapter);

            }
        }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();

            }
        }).setNeutralButton("Clear", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                ArrayList<String> cat = new ArrayList<>();
                for(int i = 0 ; i< selectedCat.length ; i++){
                    selectedCat [i] = false;
                    IntList.clear();
                }
                catTextView.setHint("select cat.");
                adapter = new BookAdapter(searchByCat(cat));
                recyclerView.setAdapter(adapter);

            }
        });
        ad.show();
    }

    private ArrayList<Book> searchByCat( ArrayList<String> cat) {
        ArrayList<Book> bookArrayList = new ArrayList<>();
        if (cat == null || cat.isEmpty()){
            return books;
        }
        else {
            for(int j = 0 ; j < cat.size() ; j++){
                for (int i = 0; i < books.size(); i++) {
                    if (books.get(i) != null && cat.get(j) != null ) {
                        if (books.get(i).getGenres().contains(cat.get(j))) {
                            bookArrayList.add(books.get(i));
                        }
                    }
                }
            }
        }
        return bookArrayList;
    }

    private ArrayList<Book> search() {
        ArrayList<Book> bookArrayList = new ArrayList<>();
        String line = searchBar.getQuery().toString();
        for (int i = 0; i < books.size(); i++) {
            if (line.equals("") || line == null) {
                bookArrayList.add(books.get(i));
            } else if (books.get(i).getBook_title().toLowerCase().contains(line.toLowerCase()) || books.get(i).getBook_authors().toLowerCase().contains(line.toLowerCase())) {
                bookArrayList.add(books.get(i));
            }
        }
        return bookArrayList;
    }
}


