package com.example.book4u;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ExchangeRateService {
    @GET("latest")
    Call<ExchangeRateResponse> getExchangeRate(
            @Query("base") String baseCurrency,
            @Query("symbols") String targetCurrency,
            @Query("apikey") String apiKey
    );
}
